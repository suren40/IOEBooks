function volts = sinewave(wt)
% Function to simulate the output of a sie wave
%   wt = Phase in radians (=omega x time)

% Simulate the output of the 
volts = sin(wt);
